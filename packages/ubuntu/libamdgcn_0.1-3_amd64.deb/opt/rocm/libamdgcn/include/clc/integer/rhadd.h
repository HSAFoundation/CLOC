#define __CLC_BODY <clc/integer/rhadd.inc>
#include <clc/integer/gentype.inc>
