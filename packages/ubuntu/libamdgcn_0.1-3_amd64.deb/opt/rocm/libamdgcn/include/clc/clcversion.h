#if __OPENCL_VERSION__ >= 110
#define CLC_VERSION_1_0 100
#define CLC_VERSION_1_1 110
#endif

#if __OPENCL_VERSION__ >= 120
#define CLC_VERSION_1_2 120
#endif
