_CLC_OVERLOAD _CLC_DECL int atom_xor(local int *p, int val);
_CLC_OVERLOAD _CLC_DECL unsigned int atom_xor(local unsigned int *p, unsigned int val);
