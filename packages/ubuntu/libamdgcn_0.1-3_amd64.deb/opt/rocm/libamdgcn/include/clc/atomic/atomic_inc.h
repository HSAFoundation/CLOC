#define atomic_inc(p) atomic_add(p, 1)
