_CLC_DECL size_t get_work_dim_ll(void);
_CLC_OVERLOAD _CLC_DECL size_t get_work_dim(void);
