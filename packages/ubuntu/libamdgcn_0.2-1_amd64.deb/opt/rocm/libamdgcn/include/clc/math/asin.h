#define __CLC_BODY <clc/math/asin.inc>
#include <clc/math/gentype.inc>
