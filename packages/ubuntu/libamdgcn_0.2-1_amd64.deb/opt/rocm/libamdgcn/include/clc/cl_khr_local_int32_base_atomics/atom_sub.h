_CLC_OVERLOAD _CLC_DECL int atom_sub(local int *p, int val);
_CLC_OVERLOAD _CLC_DECL unsigned int atom_sub(local unsigned int *p, unsigned int val);
