#define __CLC_BODY <clc/math/tan.inc>
#include <clc/math/gentype.inc>
