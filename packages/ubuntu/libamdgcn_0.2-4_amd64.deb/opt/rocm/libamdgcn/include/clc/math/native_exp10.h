#define native_exp10 exp10
