_CLC_DECL size_t get_local_size_ll(uint dim);
_CLC_OVERLOAD _CLC_DECL size_t get_local_size(uint dim);
