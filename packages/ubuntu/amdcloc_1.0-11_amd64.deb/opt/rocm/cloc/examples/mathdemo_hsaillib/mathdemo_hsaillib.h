float __sin(float in);
float __cos(float in);
float __exp(float in);
