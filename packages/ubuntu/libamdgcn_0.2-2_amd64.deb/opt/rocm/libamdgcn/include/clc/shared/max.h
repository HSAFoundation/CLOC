#define __CLC_BODY <clc/shared/max.inc>
#include <clc/integer/gentype.inc>

#define __CLC_BODY <clc/shared/max.inc>
#include <clc/math/gentype.inc>
