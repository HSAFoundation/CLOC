#define native_exp2 exp2
