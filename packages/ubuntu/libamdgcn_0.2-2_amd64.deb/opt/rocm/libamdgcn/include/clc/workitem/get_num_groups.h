_CLC_DECL size_t get_num_groups_ll(uint dim);
_CLC_OVERLOAD _CLC_DECL size_t get_num_groups(uint dim);
