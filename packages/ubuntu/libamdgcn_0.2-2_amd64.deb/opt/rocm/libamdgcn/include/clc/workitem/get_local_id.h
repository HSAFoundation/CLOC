_CLC_DECL size_t get_local_id_ll(uint dim);
_CLC_OVERLOAD _CLC_DECL size_t get_local_id(uint dim);
