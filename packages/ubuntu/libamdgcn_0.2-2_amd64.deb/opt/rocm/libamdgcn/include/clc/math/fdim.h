#define __CLC_BODY <clc/math/fdim.inc>
#include <clc/math/gentype.inc>
