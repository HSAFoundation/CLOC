#define __CLC_FUNCTION atomic_sub
#include <clc/atomic/atomic_decl.inc>
#undef __CLC_FUNCTION
#undef __CLC_DECLARE_ATOMIC
#undef __CLC_DECLARE_ATOMIC_ADDRSPACE
