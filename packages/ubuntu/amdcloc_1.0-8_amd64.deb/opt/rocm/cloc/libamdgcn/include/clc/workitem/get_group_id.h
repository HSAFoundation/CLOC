_CLC_DECL size_t get_group_id_ll(uint dim);
_CLC_OVERLOAD _CLC_DECL size_t get_group_id(uint dim);
