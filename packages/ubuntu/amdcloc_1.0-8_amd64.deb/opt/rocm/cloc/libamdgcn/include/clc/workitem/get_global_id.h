_CLC_OVERLOAD _CLC_DECL size_t get_global_id(uint dim);
